A Pen created at CodePen.io. You can find this one at https://codepen.io/chriscoyier/pen/egHEK.

 Quick googling turned up some people who had the idea a while back [1](http://www.jonathoncihlar.com/index.php?Post=nutritiontemplate) [2](http://aggregated.alanhogan.com/post/1565663374/i-would-love-to-see-something-like-this-alongside)